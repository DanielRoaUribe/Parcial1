package logica;

public class Peon extends Ficha implements Interfaz{
	private int filaInicial, columnaInicial, casillas;
	private boolean posInicial;
	
	public boolean verificarPosInicial(int filaInicial, int columnaInicial) {
		if(filaInicial == 6) {
			for (int i = 1;i<=8;i++) {
				if(columnaInicial == i) {
					posInicial = true;
					i = 9;
				}
			}

		}
		return posInicial;
	}

	@Override
	public int calcularCasillas(int fila, int columna) {
		for(int i = 2; i<=8 ; i++) {
			if(fila == i) {
				for(int j = 1;j<=8;j++) {
					if (columna == j) {
						casillas = 1;
					}
				}
			} 
		}
		
		
		if (posInicial == true) {
			casillas = 2;
		}
		return casillas;
	}
	
}
