package logica;

public class Rey {
	
}
