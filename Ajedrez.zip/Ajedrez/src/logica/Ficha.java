package logica;

public class Ficha {
	private int fila, columna, casillas;
}
