package logica;

public class Torre extends Ficha implements Interfaz{

	@Override
	public int calcularCasillas(int fila, int columna) {
		for(int i=1;i<=8;i++) {
			for(int j=1;j<=8;j++) {
				
			}
		}
		return 0;
	}
	
}
