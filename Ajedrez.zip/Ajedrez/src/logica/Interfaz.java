package logica;

public interface Interfaz {
	public int calcularCasillas(int fila,int columna);;
}
